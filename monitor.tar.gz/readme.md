解压后可直接导入Eclipse或IDEA等常用开发工具，页面已经做过加载优化，常用业务页面demo数据均已存在，可直接预览，可对接系统后台直接使用。
效果图
![输入图片说明](https://git.oschina.net/uploads/images/2017/0628/133736_aa419331_22473.png "在这里输入图片标题")
![输入图片说明](https://git.oschina.net/uploads/images/2017/0628/133809_122c2419_22473.png "在这里输入图片标题")
![输入图片说明](https://git.oschina.net/uploads/images/2017/0628/133827_9d05627f_22473.png "在这里输入图片标题")
![输入图片说明](https://git.oschina.net/uploads/images/2017/0628/133840_a68f79e0_22473.png "在这里输入图片标题")
![输入图片说明](https://git.oschina.net/uploads/images/2017/0628/133857_c2b80bd7_22473.png "在这里输入图片标题")
如果你觉得这页面对你有用，请我喝杯咖啡吧，哈哈。
![输入图片说明](https://git.oschina.net/uploads/images/2017/0628/135124_7ad0b1ff_22473.png "在这里输入图片标题")